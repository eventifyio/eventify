import os
import pytest
import sys

from eventify import Eventify

class TestEventify:

    def test_placeholder(self):
        assert True == True
