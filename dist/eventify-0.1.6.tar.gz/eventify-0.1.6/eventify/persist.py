"""
Persist Helper Module
"""

def persist_event(event):
    """
    Writes event to table to ensure
    persistence

    :param event: Event to save
    """
    print(event)
