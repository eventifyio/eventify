"""
Persist Helper Module
"""

def persist_event(event):
    """
    Writes event to table to ensure
    persistence
    """
    print(event)
